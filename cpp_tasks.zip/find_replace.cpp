#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    ifstream file("file.txt");
    ofstream out("output.txt");
    string find, replace, line;
    cin >> find >> replace;
    while (getline(file, line)) {
        size_t pos = 0;
        while ((pos = line.find(find, pos)) != string::npos) {
            line.replace(pos, find.length(), replace);
            pos += replace.length();
        }
        out << line << '\n';
    }
    return 0;
}