#include <iostream>
#include <queue>
using namespace std;

int main() {
    queue<string> buffer;
    for (int i = 0; i < 5; i++) buffer.push("Data" + to_string(i));
    while (!buffer.empty()) {
        cout << buffer.front() << endl;
        buffer.pop();
    }
    return 0;
}