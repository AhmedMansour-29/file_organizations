#include <iostream>
#include <fstream>
using namespace std;

string encrypt(string text) {
    for (char &c : text) c += 1;
    return text;
}

string decrypt(string text) {
    for (char &c : text) c -= 1;
    return text;
}

int main() {
    ifstream in("input.txt");
    ofstream out("encrypted.txt");
    string line, all;
    while (getline(in, line)) all += line + '\n';
    out << encrypt(all);
    in.close(); out.close();
    ifstream in2("encrypted.txt");
    ofstream out2("decrypted.txt");
    string encrypted, temp;
    while (getline(in2, temp)) encrypted += temp + '\n';
    out2 << decrypt(encrypted);
    return 0;
}