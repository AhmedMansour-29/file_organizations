#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> fat = {0, 1, 2, -1, 5, 6, -1};
    for (int i = 0; i < fat.size(); i++) {
        cout << "File starting at cluster " << i << ": ";
        int next = i;
        while (next != -1) {
            cout << next << " ";
            next = fat[next];
        }
        cout << endl;
    }
    return 0;
}